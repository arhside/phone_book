import data
from phone import Phone
from contact import Contact
from phone_book import PhoneBook


def look_menu():
    # Получить список контактов
    # Вывести их
    print('<<<<<<<<<>>>>>>>>>>')
    if check_empty():
        for i in range(len(pb.contacts)):
            print(f'{i+1}.{pb.contacts[i].name}')

            for phone in pb.contacts[i].phones:
                print(f'    {phone.name}: {phone.number}')
        print('<<<<<<<<<>>>>>>>>>>')


def add_menu():
    contact_name = input('Input contact name: ')

    phones = []
    while True:
        contact_phone_name = input('Input phone name: ')
        contact_phone_number = input('Input phone number: ')

        phones.append(Phone(contact_phone_name, contact_phone_number))

        user_choose = input('Add 1 number? [y/n] ')
        if user_choose != 'y':
            break
    try:
        pb.add(Contact(contact_name, phones))
        print('User was added to contact list!')
        print('<<<<<<<<<>>>>>>>>>>')
    except Exception as ex:
        print(ex)


def cast_value(value, type, msg='Error cast'):
    try:
        value = type(value)
    except:
        print(msg)
        return None
    else:
        return value


def check_empty() -> bool:
    if len(pb.contacts) == 0:
        print('Phone book is empty')
        return False
    return True


def get_index(collection) -> int:
    while True:
        print('<<<<<<<<<>>>>>>>>>>')
        user_input = input('Input index: ')

        user_input = cast_value(user_input, int)

        if user_input != None:
            if user_input <= 0 or user_input > len(collection):
                print('Error index!')
            else:
                return user_input-1


def remove_menu():
    if check_empty():
        contact = pb.get_contact(get_index(pb.contacts))
        pb.remove(contact)
        print('User was removed!')
        print('<<<<<<<<<>>>>>>>>>>')


def update_menu():
    if check_empty():
        contact = pb.get_contact(get_index(pb.contacts))

        while True:
            user_choose = input("1.Change name\n2.Change phones\n3.Back\n")
            if user_choose == '1':
                print(f'Old name: {contact.name}')
                contact.name = input('Input new name: ')
            elif user_choose == '2':
                i = 1
                print('<<<<<<<<<>>>>>>>>>>')
                for phone in contact.phones:
                    print(f'{i}.{phone.name}: {phone.number}')
                    i += 1
                print('<<<<<<<<<>>>>>>>>>>')
                index = get_index(contact.phones)
                phone_name = input('Input new name: ')
                phone_number = input('Input new number: ')

                contact.phones[index].name = phone_name
                contact.phones[index].number = phone_number

            elif user_choose == '3':
                break
            else:
                print('Error list item!')


pb = PhoneBook()


for contact in data.phone_book:
    phones = []
    for phone in contact[1]:
        phones.append(Phone(phone[0], phone[1]))
    pb.add(Contact(contact[0], phones))


while True:
    print('Welcome to Phone book\nChoose menu item:')
    user_choose = input(
        '1.Look contact list\n2.Add contact\n3.Remove contact\n4.Update contact\n5.Exit\n')
    if user_choose == '1':
        look_menu()
    elif user_choose == '2':
        add_menu()
    elif user_choose == '3':
        remove_menu()
    elif user_choose == '4':
        update_menu()
    elif user_choose == '5':
        break
    else:
        print('Error input!')



#Казино
#Косынка - карты(колода карт), 4 слота(каждый слот принимает карту от А и выше, в строгом порядке(value = prev_v +1, suit1=suit2))
#Пасьянс - карты(колода карт)
#Блекджек - карты(колода карт)

xxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxx
xxxxxxxxxxxxxxxxxxxxxxxx