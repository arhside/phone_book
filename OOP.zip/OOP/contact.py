# Информация о контакте
# Имя
# Телефон (хотя бы 1)

from phone import Phone


class Contact:
    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        if type(value) != str:
            raise Exception('Value is not str!')
        if value == '':
            raise Exception('Value is empty!')
        self.__name = value

    @property
    def phones(self):
        return self.__phones.copy()

    def __init__(self, name: str, phones: list) -> None:  # [Phone,Phone,Phone]
        if type(name) != str:
            raise Exception('Name is not a str')
        if type(phones) != list:
            raise Exception('Phones is not a list')

        for phone in phones:
            if type(phone) != Phone:
                raise Exception('phone is not a Phone')

        self.name = name
        self.__phones = phones
