# Название (Домашний, Мобильный)
# Цифры (+380717556666, 0717556666)

class Phone:

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        if type(value) != str:
            raise Exception('Value is not str!')
        if value == '':
            raise Exception('Value is empty!')
        self.__name = value

    @property
    def number(self):
        return self.__number

    @number.setter
    def number(self, value):
        if type(value) != str:
            raise Exception('Value is not str!')
        if value == '':
            raise Exception('Value is empty!')

        if value[0] == '+':
            if len(value) != 13 and not value[1:].isnumeric():
                raise Exception('Number len must be 13 symbols!')
        else:
            if len(value) != 10 and not value.isnumeric():
                raise Exception('Number len must be 10 symbols!')

        self.__number = value

    def __init__(self, name, number) -> None:
        self.name = name
        self.number = number
