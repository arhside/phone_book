# Храним контакты
# Добавляем контакты
# Удаляем контакты

from contact import Contact


class PhoneBook:

    # Добавляем контакт в список контактов
    def add(self, contact: Contact):
        self.__contacts.append(contact)

    # Удаляем контакт из списка
    def remove(self, contact: Contact):
        self.__contacts.remove(contact)

    # Получаем контакт по индексу
    def get_contact(self, index: int) -> Contact:
        return self.__contacts[index]

    # Обновляем контакт
    def update(self, index: int, contact: Contact):
        self.__contacts[index] = contact

    @property
    def contacts(self) -> list:
        return self.__contacts.copy()

    def __init__(self) -> None:
        self.__contacts = []  # List of Contact
